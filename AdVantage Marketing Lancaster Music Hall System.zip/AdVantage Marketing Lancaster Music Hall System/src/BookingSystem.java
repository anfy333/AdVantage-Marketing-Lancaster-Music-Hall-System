public interface BookingSystem {

}
